# trisha's archive

A responsive, magazine-style visual gallery for GitHub Pages.

## Preview locally
Open `index.html` in a browser. An internet connection is needed for the Google Fonts.

## Add your photographs
Put your image files in `assets/images/` and name them exactly:
- `photo-01.jpg`
- `photo-02.jpg`
- `photo-03.jpg`
- `experiment-01.jpg`

You can use `.png` or `.webp` too, but update the matching filename in `index.html`.

## Add your videos
Put MP4 files in `assets/videos/` named:
- `video-01.mp4`
- `video-02.mp4`

Optional poster/thumbnail images go in `assets/images/` as `video-01.jpg` and `video-02.jpg`.
The video controls are already included.

## Change captions
Open `index.html` and edit the text inside each card's `<h3>` and date `<span>`.

## Change contact email
In `index.html`, replace `hello@example.com` with the email address you want visitors to use.

## Publish with GitHub Pages
1. Create a new GitHub repository, for example `trishas-archive`.
2. Upload the contents of this folder (not the ZIP file itself).
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish the site. Your URL will look like `https://YOUR-USERNAME.github.io/trishas-archive/`.

No build tools or frameworks are required.
